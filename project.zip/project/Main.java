public class Main {
    public static void main(String[] args) {
        // Launching the Text Editor
        new TextEditor();
    }
}
