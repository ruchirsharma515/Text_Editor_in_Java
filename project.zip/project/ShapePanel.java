import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.awt.geom.*;
import java.io.*;
import java.util.ArrayList;

class ShapePanel extends JPanel {
    private ArrayList<DrawableShape> shapes = new ArrayList<>();
    private String currentShapeType = "Rectangle";
    private DrawableShape currentShape = null;
    private Point startDrag, endDrag;
    private boolean drawMode = true; // Determines whether drawing mode is active
    private Color strokeColor = Color.BLACK;
    private Color fillColor = Color.WHITE;

    public ShapePanel() {
        setBackground(Color.WHITE);

        // Mouse listener for shape interactions
        addMouseListener(new MouseAdapter() {
            @Override
            public void mousePressed(MouseEvent e) {
                if (!drawMode) {
                    selectShape(e.getPoint());
                    return;
                }

                startDrag = e.getPoint();
                endDrag = startDrag;

                switch (currentShapeType) {
                    case "Rectangle":
                        currentShape = new DrawableShape(new Rectangle2D.Double(startDrag.x, startDrag.y, 0, 0), strokeColor, fillColor);
                        break;
                    case "Oval":
                        currentShape = new DrawableShape(new Ellipse2D.Double(startDrag.x, startDrag.y, 0, 0), strokeColor, fillColor);
                        break;
                    case "Line":
                        currentShape = new DrawableShape(new Line2D.Double(startDrag, endDrag), strokeColor, fillColor);
                        break;
                    case "Polygon":
                        if (currentShape == null || !(currentShape.getShape() instanceof Polygon)) {
                            currentShape = new DrawableShape(new Polygon(), strokeColor, fillColor);
                            shapes.add(currentShape);
                        }
                        ((Polygon) currentShape.getShape()).addPoint(e.getX(), e.getY());
                        break;
                }
                if (!currentShapeType.equals("Polygon")) {
                    shapes.add(currentShape);
                }
                repaint();
            }

            @Override
            public void mouseReleased(MouseEvent e) {
                startDrag = null;
                endDrag = null;
                currentShape = null;
            }
        });

        // Mouse motion listener for resizing and moving shapes
        addMouseMotionListener(new MouseMotionAdapter() {
            @Override
            public void mouseDragged(MouseEvent e) {
                if (!drawMode || currentShapeType.equals("Polygon")) return;

                endDrag = e.getPoint();

                if (currentShape != null) {
                    if (currentShape.getShape() instanceof Rectangle2D) {
                        Rectangle2D rect = (Rectangle2D) currentShape.getShape();
                        rect.setFrameFromDiagonal(startDrag, endDrag);
                    } else if (currentShape.getShape() instanceof Ellipse2D) {
                        Ellipse2D oval = (Ellipse2D) currentShape.getShape();
                        oval.setFrameFromDiagonal(startDrag, endDrag);
                    } else if (currentShape.getShape() instanceof Line2D) {
                        Line2D line = (Line2D) currentShape.getShape();
                        line.setLine(startDrag, endDrag);
                    }
                }
                repaint();
            }
        });
    }

    @Override
    protected void paintComponent(Graphics g) {
        super.paintComponent(g);
        Graphics2D g2 = (Graphics2D) g;
        for (DrawableShape shape : shapes) {
            shape.draw(g2);
        }
    }

    // Allow selecting shapes for editing
    private void selectShape(Point p) {
        for (DrawableShape shape : shapes) {
            if (shape.contains(p)) {
                currentShape = shape;
                currentShape.setStrokeColor(Color.RED); // Highlight selected shape
                repaint();
                return;
            }
        }
        currentShape = null; // Deselect if no shape is found
    }

    public void setCurrentShapeType(String shapeType) {
        this.currentShapeType = shapeType;
    }

    public void setStrokeColor(Color color) {
        this.strokeColor = color;
    }

    public void setFillColor(Color color) {
        this.fillColor = color;
    }

    public void toggleDrawMode() {
        this.drawMode = !drawMode;
        repaint();
    }

    public void saveShapesToFile(File file) throws IOException {
        try (ObjectOutputStream out = new ObjectOutputStream(new FileOutputStream(file))) {
            out.writeObject(shapes);
        }
    }

    public void loadShapesFromFile(File file) throws IOException, ClassNotFoundException {
        try (ObjectInputStream in = new ObjectInputStream(new FileInputStream(file))) {
            shapes = (ArrayList<DrawableShape>) in.readObject();
            repaint();
        }
    }
}

class DrawableShape implements Serializable {
    private Shape shape;
    private Color strokeColor;
    private Color fillColor;

    public DrawableShape(Shape shape, Color strokeColor, Color fillColor) {
        this.shape = shape;
        this.strokeColor = strokeColor;
        this.fillColor = fillColor;
    }

    public Shape getShape() {
        return shape;
    }

    public void setStrokeColor(Color strokeColor) {
        this.strokeColor = strokeColor;
    }

    public void setFillColor(Color fillColor) {
        this.fillColor = fillColor;
    }

    public boolean contains(Point p) {
        if (shape instanceof Polygon) {
            return ((Polygon) shape).contains(p);
        }
        return shape.contains(p);
    }

    public void draw(Graphics2D g2) {
        g2.setColor(fillColor);
        g2.fill(shape);
        g2.setColor(strokeColor);
        g2.draw(shape);
    }
}
