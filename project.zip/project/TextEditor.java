import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.io.*;
import java.util.StringTokenizer;
//HERE I HAVE REFERRED TO ORACLE DOCS AND THE COMPLETE REFERENCE 12TH EDITION 
//*************************RUCHIR SHARMA ****************************************************
//************2310110728*********************************************************************
public class TextEditor extends JFrame {
    private JTextArea textArea; //******************************************************************* Text editing area
    private ShapePanel shapePanel; 

    public TextEditor() {
        setTitle("Advanced Text Editor with Shape Canvas");
        setSize(900, 700);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);

        JTabbedPane tabbedPane = new JTabbedPane();

        textArea = new JTextArea();
        JScrollPane textScrollPane = new JScrollPane(textArea);
        tabbedPane.addTab("Text Editor", textScrollPane);

        shapePanel = new ShapePanel();
        tabbedPane.addTab("Shape Canvas", shapePanel);

        add(tabbedPane, BorderLayout.CENTER);

        setJMenuBar(createMenuBar());

        setVisible(true);
    }

    private JMenuBar createMenuBar() {
        JMenuBar menuBar = new JMenuBar();

        JMenu fileMenu = new JMenu("File");
        JMenuItem saveTextItem = new JMenuItem("Save Text as .txt");
        JMenuItem openTextItem = new JMenuItem("Open Text File");
        JMenuItem exitItem = new JMenuItem("Exit");

        saveTextItem.addActionListener(e -> saveTextFile());
        openTextItem.addActionListener(e -> openTextFile());
        exitItem.addActionListener(e -> System.exit(0));

        fileMenu.add(openTextItem);
        fileMenu.add(saveTextItem);
        fileMenu.add(exitItem);

        JMenu editMenu = new JMenu("Edit");
        JMenuItem cutItem = new JMenuItem("Cut");
        JMenuItem copyItem = new JMenuItem("Copy");
        JMenuItem pasteItem = new JMenuItem("Paste");
        JMenuItem findReplaceItem = new JMenuItem("Find & Replace");

        cutItem.addActionListener(e -> textArea.cut());
        copyItem.addActionListener(e -> textArea.copy());
        pasteItem.addActionListener(e -> textArea.paste());
        findReplaceItem.addActionListener(e -> showFindReplaceDialog());

        editMenu.add(cutItem);
        editMenu.add(copyItem);
        editMenu.add(pasteItem);
        editMenu.addSeparator();
        editMenu.add(findReplaceItem);

        JMenu formatMenu = new JMenu("Format");
        JMenuItem changeFontItem = new JMenuItem("Change Font & Size");
        JMenuItem changeCaseItem = new JMenuItem("Change Case");
        JMenuItem wordCountItem = new JMenuItem("Word & Character Count");

        changeFontItem.addActionListener(e -> changeFontAndSize());
        changeCaseItem.addActionListener(e -> changeCase());
        wordCountItem.addActionListener(e -> countWordsAndCharacters());

        formatMenu.add(changeFontItem);
        formatMenu.add(changeCaseItem);
        formatMenu.addSeparator();
        formatMenu.add(wordCountItem);

        JMenu shapeMenu = new JMenu("Shapes");
        JMenuItem rectangleItem = new JMenuItem("Rectangle");
        JMenuItem ovalItem = new JMenuItem("Oval");
        JMenuItem lineItem = new JMenuItem("Line");
        JMenuItem polygonItem = new JMenuItem("Polygon (Triangle)");
        JMenuItem strokeColorItem = new JMenuItem("Set Stroke Color");
        JMenuItem fillColorItem = new JMenuItem("Set Fill Color");
        JMenuItem toggleDrawItem = new JMenuItem("Toggle Draw Mode");
        JMenuItem saveShapesItem = new JMenuItem("Save Shapes");
        JMenuItem loadShapesItem = new JMenuItem("Load Shapes");

        rectangleItem.addActionListener(e -> shapePanel.setCurrentShapeType("Rectangle"));
        ovalItem.addActionListener(e -> shapePanel.setCurrentShapeType("Oval"));
        lineItem.addActionListener(e -> shapePanel.setCurrentShapeType("Line"));
        polygonItem.addActionListener(e -> shapePanel.setCurrentShapeType("Polygon"));
        strokeColorItem.addActionListener(e -> chooseStrokeColor());
        fillColorItem.addActionListener(e -> chooseFillColor());
        toggleDrawItem.addActionListener(e -> shapePanel.toggleDrawMode());
        saveShapesItem.addActionListener(e -> saveShapesToFile());
        loadShapesItem.addActionListener(e -> loadShapesFromFile());

        shapeMenu.add(rectangleItem);
        shapeMenu.add(ovalItem);
        shapeMenu.add(lineItem);
        shapeMenu.add(polygonItem);
        shapeMenu.addSeparator();
        shapeMenu.add(strokeColorItem);
        shapeMenu.add(fillColorItem);
        shapeMenu.addSeparator();
        shapeMenu.add(toggleDrawItem);
        shapeMenu.addSeparator();
        shapeMenu.add(saveShapesItem);
        shapeMenu.add(loadShapesItem);

        menuBar.add(fileMenu);
        menuBar.add(editMenu);
        menuBar.add(formatMenu);
        menuBar.add(shapeMenu);

        return menuBar;
    }

    //*************************************** Save text to a file
    private void saveTextFile() {
        JFileChooser fileChooser = new JFileChooser();
        fileChooser.setFileFilter(new javax.swing.filechooser.FileNameExtensionFilter("Text Files (*.txt)", "txt"));

        int returnValue = fileChooser.showSaveDialog(this);
        if (returnValue == JFileChooser.APPROVE_OPTION) {
            File file = fileChooser.getSelectedFile();

            // Ensure the file has a .txt extension
            if (!file.getName().endsWith(".txt")) {
                file = new File(file.getAbsolutePath() + ".txt");
            }

            try (BufferedWriter writer = new BufferedWriter(new FileWriter(file))) {
                writer.write(textArea.getText());
                JOptionPane.showMessageDialog(this, "File saved successfully.");
            } catch (IOException e) {
                JOptionPane.showMessageDialog(this, "Error saving file: " + e.getMessage());
            }
        }
    }

    //***************************************Open a file and load its content
    private void openTextFile() {
        JFileChooser fileChooser = new JFileChooser();
        fileChooser.setFileFilter(new javax.swing.filechooser.FileNameExtensionFilter("Text Files (*.txt)", "txt"));

        int returnValue = fileChooser.showOpenDialog(this);
        if (returnValue == JFileChooser.APPROVE_OPTION) {
            File file = fileChooser.getSelectedFile();
            try (BufferedReader reader = new BufferedReader(new FileReader(file))) {
                textArea.read(reader, null);
                JOptionPane.showMessageDialog(this, "File loaded successfully.");
            } catch (IOException e) {
                JOptionPane.showMessageDialog(this, "Error loading file: " + e.getMessage());
            }
        }
    }

    //*****************************Show Find & Replace Dialog
    private void showFindReplaceDialog() {
        new FindReplaceDialog(this, textArea).setVisible(true);
    }

    //************************* Change font and size**********************
    private void changeFontAndSize() {
        String fontName = JOptionPane.showInputDialog(this, "Enter Font Name (e.g., Arial):");
        String fontSizeStr = JOptionPane.showInputDialog(this, "Enter Font Size (e.g., 14):");

        if (fontName != null && fontSizeStr != null) {
            try {
                int fontSize = Integer.parseInt(fontSizeStr);
                textArea.setFont(new Font(fontName, Font.PLAIN, fontSize));
                JOptionPane.showMessageDialog(this, "Font updated successfully.");
            } catch (NumberFormatException e) {
                JOptionPane.showMessageDialog(this, "Invalid font size!");
            }
        }
    }

    //*************************************Change case of selected text*********************************************
    private void changeCase() {
        String selectedText = textArea.getSelectedText();
        if (selectedText != null) {
            String[] options = {"UPPERCASE", "lowercase", "Capitalize"};
            int choice = JOptionPane.showOptionDialog(
                    this, "Choose Case:", "Change Case",
                    JOptionPane.DEFAULT_OPTION, JOptionPane.PLAIN_MESSAGE,
                    null, options, options[0]);

            if (choice >= 0) {
                String updatedText = switch (choice) {
                    case 0 -> selectedText.toUpperCase();
                    case 1 -> selectedText.toLowerCase();
                    case 2 -> capitalize(selectedText);
                    default -> selectedText;
                };
                textArea.replaceSelection(updatedText);
            }
        }
    }

    //*********************************CAPITALIZE THE TEXT*****************************************************
    private String capitalize(String text) {
        if (text.isEmpty()) return text;
        return Character.toUpperCase(text.charAt(0)) + text.substring(1).toLowerCase();
    }

    //******************************COUNT WORDS AND CHARACTERS
    private void countWordsAndCharacters() {
        String text = textArea.getText().trim();
        int wordCount = text.isEmpty() ? 0 : new StringTokenizer(text).countTokens();
        int charCount = text.length();
        JOptionPane.showMessageDialog(this, "Words: " + wordCount + ", Characters: " + charCount);
    }

    //********************************CHOOSING STROKE COLOR******************************************
    private void chooseStrokeColor() {
        Color color = JColorChooser.showDialog(this, "Choose Stroke Color", Color.BLACK);
        if (color != null) {
            shapePanel.setStrokeColor(color);
        }
    }

    //******************************CHOOSING FILL COLOUR*************************************
    private void chooseFillColor() {
        Color color = JColorChooser.showDialog(this, "Choose Fill Color", Color.WHITE);
        if (color != null) {
            shapePanel.setFillColor(color);
        }
    }

    //*********************SAVING SHAPES TO FILE**************************************
    private void saveShapesToFile() {
        JFileChooser fileChooser = new JFileChooser();
        int returnValue = fileChooser.showSaveDialog(this);
        if (returnValue == JFileChooser.APPROVE_OPTION) {
            File file = fileChooser.getSelectedFile();
            try {
                shapePanel.saveShapesToFile(file);
                JOptionPane.showMessageDialog(this, "Shapes saved successfully!");
            } catch (IOException e) {
                JOptionPane.showMessageDialog(this, "Error saving shapes: " + e.getMessage());
            }
        }
    }

    //************************LOADING SHAPES FROM FILE*****************************
    private void loadShapesFromFile() {
        JFileChooser fileChooser = new JFileChooser();
        int returnValue = fileChooser.showOpenDialog(this);
        if (returnValue == JFileChooser.APPROVE_OPTION) {
            File file = fileChooser.getSelectedFile();
            try {
                shapePanel.loadShapesFromFile(file);
                JOptionPane.showMessageDialog(this, "Shapes loaded successfully!");
            } catch (IOException | ClassNotFoundException e) {
                JOptionPane.showMessageDialog(this, "Error loading shapes: " + e.getMessage());
            }
        }
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(TextEditor::new);
    }
}
