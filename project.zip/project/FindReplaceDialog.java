import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class FindReplaceDialog extends JDialog {
    private JTextArea textArea;
    private JTextField findField;
    private JTextField replaceField;
    private JButton findButton, replaceButton, replaceAllButton;

    public FindReplaceDialog(JFrame parent, JTextArea textArea) {
        super(parent, "Find & Replace", true);
        this.textArea = textArea;

        setLayout(new GridBagLayout());
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.fill = GridBagConstraints.HORIZONTAL;
        gbc.insets = new Insets(5, 5, 5, 5);

        // Find Field
        gbc.gridx = 0;
        gbc.gridy = 0;
        add(new JLabel("Find:"), gbc);

        findField = new JTextField(20);
        gbc.gridx = 1;
        gbc.gridy = 0;
        add(findField, gbc);

        // Replace Field
        gbc.gridx = 0;
        gbc.gridy = 1;
        add(new JLabel("Replace:"), gbc);

        replaceField = new JTextField(20);
        gbc.gridx = 1;
        gbc.gridy = 1;
        add(replaceField, gbc);

        // Buttons
        findButton = new JButton("Find");
        replaceButton = new JButton("Replace");
        replaceAllButton = new JButton("Replace All");

        JPanel buttonPanel = new JPanel();
        buttonPanel.add(findButton);
        buttonPanel.add(replaceButton);
        buttonPanel.add(replaceAllButton);

        gbc.gridx = 0;
        gbc.gridy = 2;
        gbc.gridwidth = 2;
        add(buttonPanel, gbc);

        // Action Listeners
        findButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                findText();
            }
        });

        replaceButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                replaceText();
            }
        });

        replaceAllButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                replaceAllText();
            }
        });

        pack();
        setLocationRelativeTo(parent);
    }

    private void findText() {
        String findText = findField.getText();
        String content = textArea.getText();

        if (findText.isEmpty()) {
            JOptionPane.showMessageDialog(this, "Find field is empty!", "Error", JOptionPane.ERROR_MESSAGE);
            return;
        }

        int startIndex = textArea.getCaretPosition();
        int index = content.indexOf(findText, startIndex);

        if (index == -1) {
            JOptionPane.showMessageDialog(this, "Text not found!", "Info", JOptionPane.INFORMATION_MESSAGE);
        } else {
            textArea.select(index, index + findText.length());
        }
    }

    private void replaceText() {
        String findText = findField.getText();
        String replaceText = replaceField.getText();

        if (textArea.getSelectedText() != null && textArea.getSelectedText().equals(findText)) {
            textArea.replaceSelection(replaceText);
        } else {
            findText();
        }
    }

    private void replaceAllText() {
        String findText = findField.getText();
        String replaceText = replaceField.getText();
        String content = textArea.getText();

        if (findText.isEmpty()) {
            JOptionPane.showMessageDialog(this, "Find field is empty!", "Error", JOptionPane.ERROR_MESSAGE);
            return;
        }

        content = content.replace(findText, replaceText);
        textArea.setText(content);

        JOptionPane.showMessageDialog(this, "All occurrences replaced!", "Info", JOptionPane.INFORMATION_MESSAGE);
    }
}
